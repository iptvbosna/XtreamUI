<?php
include "session.php"; include "functions.php";
if ((!$rPermissions["is_admin"]) OR (!hasPermissions("adv", "stream_tools"))) { exit; }

if (isset($_POST["replace_ip"])) {
	$rOldIP = ESC(str_replace("/", "\/", $_POST["old_ip"]));
	$rNewIP = ESC(str_replace("/", "\/", $_POST["new_ip"]));
	$db->query("UPDATE `streaming_servers` SET `server_ip` = REPLACE(`server_ip`, '".$rOldIP."', '".$rNewIP."');");
	$_STATUS = 1;	
}

if ($rSettings["sidebar"]) {
    include "header_sidebar.php";
} else {
    include "header.php";
}
        if ($rSettings["sidebar"]) { ?>
        <div class="content-page"><div class="content boxed-layout-ext"><div class="container-fluid">
        <?php } else { ?>
        <div class="wrapper boxed-layout-ext"><div class="container-fluid">
        <?php } ?>
                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box">
                            <div class="page-title-right">
                                <ol class="breadcrumb m-0">
									<li>
                                        <a href="./servers.php">
								        <button type="button" class="btn btn-primary waves-effect waves-light btn-sm"><i class="mdi mdi-keyboard-backspace"></i>  <?=$_["back_to_manager_servers"]?></button>
									    </a>	
                                    </li>
                                </ol>
                            </div>
                            <h4 class="page-title"> <?=$_["ip_server_change"]?> </h4>
                        </div>
                    </div>
                </div>     
                <!-- end page title --> 
                <div class="row">
                    <div class="col-xl-12">
                        <?php if ((isset($_STATUS)) && ($_STATUS == 1)) { if (!$rSettings["sucessedit"]) { ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                             <?=$_["the_ip_replacement_was_successful"]?>
                        </div>
						<?php } else { ?>
                    <script type="text/javascript">
  					swal("", '<?=$_["the_ip_replacement_was_successful"]?>.', "success");
  					</script>
                        <?php } } ?>
                        <div class="card">
                            <div class="card-body">
								<div id="basicwizard">
									<ul class="nav nav-pills bg-light nav-justified form-wizard-header mb-4">
										<li class="nav-item">
											<a href="#ip-replacement" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2"> 
												<i class="mdi mdi-ip mr-1"></i>
												<span class="d-none d-sm-inline"> <?=$_["ip_change"]?> </span>
											</a>
										</li>
									</ul>
									<div class="tab-pane" id="ip-replacement">
											<form action="./ip_change.php" method="POST" id="tools_form" data-parsley-validate="">
                                                <div class="row">
                                                    <div class="col-12">
														<p class="sub-header">
                                                             <?=$_["the_ip_replacement_tool"]?> 
                                                        </p>
                                                        <div class="form-group row mb-4">
                                                            <label class="col-md-4 col-form-label" for="old_ip"><?=$_["old_ip"]?> </label>
                                                            <div class="col-md-8">
                                                                <input type="text" class="form-control" id="old_ip" name="old_ip" value="" placeholder="127.0.0.1" required data-parsley-trigger="change">
                                                            </div>
                                                        </div>
														<div class="form-group row mb-4">
                                                            <label class="col-md-4 col-form-label" for="new_ip"> <?=$_["new_ip"]?> </label>
                                                            <div class="col-md-8">
                                                                <input type="text" class="form-control" id="new_ip" name="new_ip" value="" placeholder="127.0.0.1" required data-parsley-trigger="change">
                                                            </div>
                                                        </div>
                                                    </div> <!-- end col -->
                                                </div> <!-- end row -->
                                                <ul class="list-inline wizard mb-0">
													<li class="list-inline-item">
														<div class="custom-control custom-checkbox">
															<input type="checkbox" class="custom-control-input" id="confirmReplace">
															<label class="custom-control-label" for="confirmReplace"> <?=$_["i_confirm_that_i_want_to replace_the_old_ip"]?> </label>
														</div>
													</li>
                                                    <li class="list-inline-item float-right">
                                                        <input disabled name="replace_ip" id="replace_ip" type="submit" class="btn btn-primary" value=" <?=$_["replace_ip"]?>" />
                                                    </li>
                                                </ul>
											</form>
										</div>
								</div> <!-- end #basicwizard-->
                            </div> <!-- end card-body -->
                        </div> <!-- end card-->
                    </div> <!-- end col -->
                </div>
            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->
        <?php if ($rAdminSettings["sidebar"]) { echo "</div>"; } ?>
        <!-- Footer Start -->
        <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 copyright text-center"><?=getFooter()?></div>
                </div>
            </div>
        </footer>
        <!-- end Footer -->

        <script src="assets/js/vendor.min.js"></script>
        <script src="assets/libs/jquery-toast/jquery.toast.min.js"></script>
        <script src="assets/libs/jquery-nice-select/jquery.nice-select.min.js"></script>
        <script src="assets/libs/switchery/switchery.min.js"></script>
        <script src="assets/libs/select2/select2.min.js"></script>
        <script src="assets/libs/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
        <script src="assets/libs/bootstrap-maxlength/bootstrap-maxlength.min.js"></script>
        <script src="assets/libs/clockpicker/bootstrap-clockpicker.min.js"></script>
        <script src="assets/libs/moment/moment.min.js"></script>
        <script src="assets/libs/daterangepicker/daterangepicker.js"></script>
        <script src="assets/libs/datatables/jquery.dataTables.min.js"></script>
        <script src="assets/libs/datatables/dataTables.bootstrap4.js"></script>
        <script src="assets/libs/datatables/dataTables.responsive.min.js"></script>
        <script src="assets/libs/datatables/responsive.bootstrap4.min.js"></script>
        <script src="assets/libs/datatables/dataTables.buttons.min.js"></script>
        <script src="assets/libs/datatables/buttons.bootstrap4.min.js"></script>
        <script src="assets/libs/datatables/buttons.html5.min.js"></script>
        <script src="assets/libs/datatables/buttons.flash.min.js"></script>
        <script src="assets/libs/datatables/buttons.print.min.js"></script>
        <script src="assets/libs/datatables/dataTables.keyTable.min.js"></script>
        <script src="assets/libs/datatables/dataTables.select.min.js"></script>
        <script src="assets/libs/parsleyjs/parsley.min.js"></script>
        <script src="assets/libs/twitter-bootstrap-wizard/jquery.bootstrap.wizard.min.js"></script>
        <script src="assets/js/pages/form-wizard.init.js"></script>
        <script src="assets/js/app.min.js"></script>
        
		<script>
        $(document).ready(function() {
			$('select.select').select2({width: '100%'});
            $(window).keypress(function(event){
                if(event.which == 13 && event.target.nodeName != "TEXTAREA") return false;
            });
			$("#confirmReplace").change(function() {
				if ($(this).is(":checked")) {
					$("#replace_ip").attr("disabled", false);
				} else {
					$("#replace_ip").attr("disabled", true);
				}
			});
            $("form").attr('autocomplete', 'off');
        });
        </script>
    </body>
</html>