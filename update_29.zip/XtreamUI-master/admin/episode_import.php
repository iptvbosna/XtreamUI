<?php
include "session.php"; include "functions.php";
if (!$rPermissions["is_admin"]) { exit; }
$rTranscodeProfiles = getTranscodeProfiles();
$rCategories = getCategories("series");
if (isset($_POST["submit_stream"])) {

  if ((isset($_POST["m3u_file"])) OR (isset($_POST["m3u_url"]))) {
	  
	
		if (isset($_POST["direct_source"])) {
			$_POST['direct_source'] = 1;
		} else {
			$_POST['direct_source'] = 0;
		}
		
        $rFile = '';
        if (!empty($_POST['m3u_url'])) {
            $rFile = file_get_contents($_POST['m3u_url']);
        } else if ((!empty($_POST['m3u_file']))) {
            $rFile = $_POST['m3u_file'];
        }
        preg_match_all('/(?P<tag>#EXTINF:)|(?:(?P<prop_key>[-a-z]+)=\"(?P<prop_val>[^"]+)")|(?<name>,[^\r\n]+)|(?<url>http[^\s]+)/', $rFile, $rMatches);
        $rResults = [];
        $rIndex = -1;
        for ($i = 0; $i < count($rMatches[0]); $i++) {
            $rItem = $rMatches[0][$i];
            if (!empty($rMatches['tag'][$i])) {
                ++$rIndex;
            } elseif (!empty($rMatches['prop_key'][$i])) {
                $rResults[$rIndex][$rMatches['prop_key'][$i]] = trim($rMatches['prop_val'][$i]);
            } elseif (!empty($rMatches['name'][$i])) {
                $rResults[$rIndex]['name'] = trim(substr($rItem, 1));
            } elseif (!empty($rMatches['url'][$i])) {
                $rResults[$rIndex]['url'] = trim($rItem);
            }
        }
		$season = strlen($_POST['season']) == 1 ? "0".$_POST['season'] : $_POST['season'];
		$name_serie = getSeries($_POST['serie_id'])[0]['title'];
		$episode = 0;
        foreach ($rResults as $rResult) {
			$episode++;
			$ep = strlen($episode) == 1 ? "0".$episode : $episode;
			//$name = "{$name_serie}.S{$season}.E{$episode}";
			$name = $rResult['name'];
			$db->query("INSERT INTO `streams` (`type`, `category_id`, `stream_display_name`, `stream_source`, `stream_icon`, `notes`, `created_channel_location`, `enable_transcode`, `transcode_attributes`, `custom_ffmpeg`, `movie_propeties`, `movie_subtitles`, `read_native`, `target_container`, `stream_all`, `remove_subtitles`, `custom_sid`, `epg_id`, `channel_id`, `epg_lang`, `order`, `auto_restart`, `transcode_profile_id`, `pids_create_channel`, `cchannel_rsources`, `gen_timestamps`, `added`, `series_no`, `direct_source`, `tv_archive_duration`, `tv_archive_server_id`, `tv_archive_pid`, `movie_symlink`, `redirect_stream`, `rtmp_output`, `number`, `allow_record`, `probesize_ondemand`, `custom_map`, `external_push`, `delay_minutes`) VALUES (5,	'".$_POST['category_id']."',	'".$name."',	'[\"".$rResult['url']."\"]',	'".$rResult['tvg-logo']."',	'',	NULL,	0,	'[]',	'',	'{\"movie_image\":\"".$rResult['tvg-logo']."\",\"backdrop_path\":[],\"youtube_trailer\":\"\",\"genre\":\"\",\"plot\":\"\",\"cast\":\"\",\"rating\":\"\",\"director\":\"\",\"releasedate\":\"\",\"tmdb_id\":\"\"}',	'',	0,	'[\"mp4\"]',	0,	0,	NULL,	NULL,	NULL,	NULL,	0,	'',	0,	'',	'',	1,	".time().",	0,	'".$_POST['direct_source']."',	0,	0,	0,	'".$_POST['direct_source']."',	'".$_POST['direct_source']."',	0,	0,	0,	128000,	'',	'',	0);");
			$newid = $db->insert_id;
			$db->query("INSERT INTO `streams_sys` (`stream_id`, `server_id`, `parent_id`, `pid`, `to_analyze`, `stream_status`, `stream_started`, `stream_info`, `monitor_pid`, `current_source`, `bitrate`, `progress_info`, `on_demand`, `delay_pid`, `delay_available_at`) VALUES (".$newid.",	'".$_POST['servers']."',	NULL,	NULL,	0,	0,	NULL,	'',	NULL,	NULL,	'',	'',	0,	NULL,	NULL);");
			$db->query("INSERT INTO `series_episodes` (`season_num`, `series_id`, `stream_id`) VALUES ('".$_POST['season']."',	'".$_POST['serie_id']."',	'".$newid."');");
		}
		$_STATUS == 0;
  }
}

if ($rSettings["sidebar"]) {
    include "header_sidebar.php";
} else {
    include "header.php";
}
 if ($rSettings["sidebar"]) { ?>
        <div class="content-page"><div class="content boxed-layout-ext"><div class="container-fluid">
        <?php } else { ?>
        <div class="wrapper boxed-layout-ext"><div class="container-fluid">
        <?php } ?>
                <!-- start page title -->
                <div class="row">
                    <div class="col-xl-12">
                        <div class="page-title-box">
                            <div class="page-title-right">
                                <ol class="breadcrumb m-0">
									<li>
                                        <a href="./episodes.php?sid=<?=$_POST['serie_id'] ?>">
								        <button type="button" class="btn btn-primary waves-effect waves-light btn-sm"><i class="mdi mdi-keyboard-backspace"></i> <?=$_["back_to_episodes"]?></button>
									    </a>	
                                    </li>
                                </ol>
                            </div>
                            <h4 class="page-title"><?php if (isset($rStream)) { echo $_["edit"]; } else { echo $_["import"]; } ?> <?=$_["episodes"]?></h4>
                        </div>
                    </div>
                </div>     
                <!-- end page title --> 
                <div class="row">
                    <div class="col-xl-12">
                        <?php if (isset($_POST["submit_stream"])) { ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <?=$_["episodes_importation_was_completed_successfully"]?>
                        </div>
                        <?php }  ?>

                        <div class="card">
                            <div class="card-body">
                                <form action="./episode_import.php<?php if (isset($_GET["id"])) { echo "?id=".$_GET["id"]; } ?>" method="POST" id="stream_form">
                                    <?php if (isset($rStream)) { ?>
                                    <input type="hidden" name="edit" value="<?=$rStream["id"]?>" />
                                    <?php } ?>
                                    <input type="hidden" name="server_tree_data" id="server_tree_data" value="" />
                                    <div id="basicwizard">
                                        <ul class="nav nav-pills bg-light nav-justified form-wizard-header mb-4">
                                            <li class="nav-item">
                                                <a href="#stream-details" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2"> 
                                                    <i class="mdi mdi-account-card-details-outline mr-1"></i>
                                                    <span class="d-none d-sm-inline"><?=$_["details"]?></span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="#advanced-options" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">
                                                    <i class="mdi mdi-folder-alert-outline mr-1"></i>
                                                    <span class="d-none d-sm-inline"><?=$_["advanced"]?></span>
                                                </a>
                                            </li>
                                           
                                            <li class="nav-item">
                                                <a href="#load-balancing" data-toggle="tab" class="nav-link rounded-0 pt-2 pb-2">
                                                    <i class="mdi mdi-server-network mr-1"></i>
                                                    <span class="d-none d-sm-inline"><?=$_["servers"]?></span>
                                                </a>
                                            </li>
                                        </ul>
                                        <div class="tab-content b-0 mb-0 pt-0">
                                            <div class="tab-pane" id="stream-details">
                                                <div class="row">
                                                    <div class="col-12">
                                                            <div class="form-group row mb-4">
                                                            <label class="col-md-4 col-form-label" for="m3u_file"><?=$_["m3u_content"]?></label>
                                                            <div class="col-md-8">
                                                                <textarea style="width:100%; height:200px; border: 1px solid #ced4da;" name="m3u_file" id="m3u_file" /></textarea>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row mb-4">
                                                            <label class="col-md-4 col-form-label" for="serie_id"><?=$_["select_serie"]?></label>
                                                            <div class="col-md-8">
                                                                <select name="serie_id" id="serie_id" class="form-control" data-toggle="select2">
                                                                    <?php foreach (getSeries() as $rSeries) { ?>
                                                                    <option value='<?=$rSeries['id'];?>'><?=$rSeries['title'];?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </div>
                                                        </div>
														<div class="form-group row mb-4">
                                                            <label class="col-md-4 col-form-label" for="season"><?=$_["season"]?></label>
                                                            <div class="col-md-2">
                                                                <input type="number" class="form-control" id="season" name="season">
                                                            </div>
                                                        </div>
														<div class="form-group row mb-4" style="display:none">
                                                            <label class="col-md-4 col-form-label" for="movie_propeties"><?=$_["movie_propeties"]?></label>
                                                            <div class="col-md-8">
                                                                <input type="text" value ='{"movie_image":null,"plot":null,"releasedate":null,"rating":null}' class="form-control" id="movie_propeties" name="movie_propeties" value="<?php if (isset($rStream)) { echo $rStream["movie_propeties"]; } ?>">
                                                            </div>
                                                        </div>
														<div class="form-group row mb-4" style="display:none">
                                                            <label class="col-md-4 col-form-label" for="target_container"><?=$_["format_movie"]?></label>
                                                            <div class="col-md-8">
                                                                <input type="text" value ='["mp4"]' class="form-control" id="target_container" name="target_container" value="<?php if (isset($rStream)) { echo $rStream["target_container"]; } ?>">
                                                           </div>
                                                        </div>
                                                        <div class="form-group row mb-4" style="display:none">
                                                            <label class="col-md-4 col-form-label" for="notes"><?=$_["notes"]?></label>
                                                            <div class="col-md-8">
                                                                <textarea id="notes" name="notes" class="form-control" rows="3" placeholder=""><?php if (isset($rStream)) { echo $rStream["notes"]; } ?></textarea>
                                                            </div>
                                                        </div>
                                                    </div> <!-- end col -->
                                                </div> <!-- end row -->
                                                <ul class="list-inline wizard mb-0">
                                                    <li class="next list-inline-item float-right">
                                                        <a href="javascript: void(0);" class="btn btn-secondary"><?=$_["next"]?></a>
                                                    </li>
                                                </ul>
                                            </div>

                                            <div class="tab-pane" id="advanced-options">
                                                <div class="row">
                                                    <div class="col-12">
                                                        <div class="form-group row mb-4" style="display:none">
                                                            <label class="col-md-4 col-form-label" for="gen_timestamps"><?=$_["generate_pts"]?> <i data-toggle="tooltip" data-placement="top" title="" data-original-title="<?=$_["allow_ffmpeg_to_generate"]?>" class="mdi mdi-information"></i></label>
                                                            <div class="col-md-2">
                                                                <input name="gen_timestamps" id="gen_timestamps" type="checkbox" <?php if (isset($rStream)) { if ($rStream["gen_timestamps"] == 1) { echo "checked "; } } else { echo "checked "; } ?>data-plugin="switchery" class="js-switch" data-color="#039cfd"/>
                                                            </div>
                                                            <label class="col-md-4 col-form-label" for="read_native"><?=$_["native_frames"]?> <i data-toggle="tooltip" data-placement="top" title="" data-original-title="<?=$_["you_should_always_read_live_streams_as_non-native_frames"]?>" class="mdi mdi-information"></i></label>
                                                            <div class="col-md-2">
                                                                <input name="read_native" id="read_native" type="checkbox" <?php if (isset($rStream)) { if ($rStream["read_native"] == 1) { echo "checked "; } } ?>data-plugin="switchery" class="js-switch" data-color="#039cfd"/>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row mb-4" style="display:none">
                                                            <label class="col-md-4 col-form-label" for="stream_all"><?=$_["stream_all_codecs"]?> <i data-toggle="tooltip" data-placement="top" title="" data-original-title="<?=$_["this_option_will_stream_all_codecs_from_your_stream"]?>" class="mdi mdi-information"></i></label>
                                                            <div class="col-md-2">
                                                                <input name="stream_all" id="stream_all" type="checkbox" <?php if (isset($rStream)) { if ($rStream["stream_all"] == 1) { echo "checked "; } } ?>data-plugin="switchery" class="js-switch" data-color="#039cfd"/>
                                                            </div>
                                                            <label class="col-md-4 col-form-label" for="allow_record"><?=$_["allow_recording"]?></label>
                                                            <div class="col-md-2">
                                                                <input name="allow_record" id="allow_record" type="checkbox" <?php if (isset($rStream)) { if ($rStream["allow_record"] == 1) { echo "checked "; } } ?>data-plugin="switchery" class="js-switch" data-color="#039cfd"/>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row mb-4">
                                                            <label style="display:none" class="col-md-4 col-form-label" for="rtmp_output"><?=$_["allow_rtmp_output"]?> <i data-toggle="tooltip" data-placement="top" title="" data-original-title="<?=$_["enable_rtmp_output_for_this_channel"]?>" class="mdi mdi-information"></i></label>
                                                            <div style="display:none" class="col-md-2">
                                                                <input name="rtmp_output" id="rtmp_output" type="checkbox" <?php if (isset($rStream)) { if ($rStream["rtmp_output"] == 1) { echo "checked "; } } ?>data-plugin="switchery" class="js-switch" data-color="#039cfd"/>
                                                            </div>
                                                           <label class="col-md-4 col-form-label" for="direct_source"><?=$_["direct_source"]?> <i data-toggle="tooltip" data-placement="top" title="" data-original-title="<?=$_["dont_run_source_through_xtream_codes"]?>" class="mdi mdi-information"></i></label>
                                                            <div class="col-md-2">
                                                                <input name="direct_source" id="direct_source" type="checkbox" <?php if (isset($rStream)) { if ($rStream["direct_source"] == 1) { echo "checked "; } } ?>data-plugin="switchery" class="js-switch" data-color="#039cfd"/>
                                                            </div>
                                                        </div>
                                                        <div style="display:none" class="form-group row mb-4">
                                                            <label class="col-md-4 col-form-label" for="custom_sid"><?=$_["custom_channel_sid"]?> <i data-toggle="tooltip" data-placement="top" title="" data-original-title="<?=$_["here_you_can_specify_the_sid"]?>" class="mdi mdi-information"></i></label>
                                                            <div class="col-md-2">
                                                                <input type="text" class="form-control" id="custom_sid" name="custom_sid" value="<?php if (isset($rStream)) { echo $rStream["custom_sid"]; } ?>">
                                                            </div>
                                                            <label class="col-md-4 col-form-label" for="delay_minutes"><?=$_["minute_delay"]?> <i data-toggle="tooltip" data-placement="top" title="" data-original-title="<?=$_[""]?>" class="mdi mdi-information"></i></label>
                                                            <div class="col-md-2">
                                                                <input type="text" class="form-control" id="delay_minutes" name="delay_minutes" value="<?php if (isset($rStream)) { echo $rStream["delay_minutes"]; } else { echo "0"; } ?>">
                                                            </div>
                                                        </div>
                                                        <div class="form-group row mb-4" style="display:none">
                                                            <label class="col-md-4 col-form-label" for="custom_ffmpeg"><?=$_["custom_ffmpeg_command"]?> <i data-toggle="tooltip" data-placement="top" title="" data-original-title="<?=$_["in_this_field_you_can_write"]?>" class="mdi mdi-information"></i></label>
                                                            <div class="col-md-8">
                                                                <input type="text" class="form-control" id="custom_ffmpeg" name="custom_ffmpeg" value="<?php if (isset($rStream)) { echo $rStream["custom_ffmpeg"]; } ?>">
                                                            </div>
                                                        </div>
                                                        <div class="form-group row mb-4" style="display:none">
                                                            <label class="col-md-4 col-form-label" for="user_agent"><?=$_["user_agent"]?></label>
                                                            <div class="col-md-8">
                                                                <input type="text" class="form-control" id="user_agent" name="user_agent" value="<?php if (isset($rStreamOptions[1])) { echo $rStreamOptions[1]["value"]; } else { echo $rStreamArguments["user_agent"]["argument_default_value"]; } ?>">
                                                            </div>
                                                        </div>
                                                        <div class="form-group row mb-4" style="display:none">
                                                            <label class="col-md-4 col-form-label" for="http_proxy"><?=$_["http_proxy"]?> <i data-toggle="tooltip" data-placement="top" title="" data-original-title="<?=$_["format_ip_port"]?>" class="mdi mdi-information"></i></label>
                                                            <div class="col-md-8">
                                                                <input type="text" class="form-control" id="http_proxy" name="http_proxy" value="<?php if (isset($rStreamOptions[2])) { echo $rStreamOptions[1]["value"]; } else { echo $rStreamArguments["proxy"]["argument_default_value"]; } ?>">
                                                            </div>
                                                        </div>
                                                        <div class="form-group row mb-4">
                                                            <label class="col-md-4 col-form-label" for="transcode_profile_id"><?=$_["transcoding_profile"]?> <i data-toggle="tooltip" data-placement="top" title="" data-original-title="<?=$_["episode_tooltip_7"]?>" class="mdi mdi-information"></i></label>
                                                            <div class="col-md-8">
                                                                <select name="transcode_profile_id" id="transcode_profile_id" class="form-control" data-toggle="select2">
                                                                    <option <?php if (isset($rStream)) { if (intval($rStream["transcode_profile_id"]) == 0) { echo "selected "; } } ?>value="0"><?=$_["trancoding_disabled"]?></option>
                                                                    <?php foreach ($rTranscodeProfiles as $rProfile) { ?>
                                                                    <option <?php if (isset($rStream)) { if (intval($rStream["transcode_profile_id"]) == intval($rProfile["profile_id"])) { echo "selected "; } } ?>value="<?=$rProfile["profile_id"]?>"><?=$rProfile["profile_name"]?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div> <!-- end col -->
                                                </div> <!-- end row -->
                                                <ul class="list-inline wizard mb-0">
                                                    <li class="previous list-inline-item">
                                                        <a href="javascript: void(0);" class="btn btn-secondary"><?=$_["prev"]?></a>
                                                    </li>
                                                    <li class="next list-inline-item float-right">
                                                        <a href="javascript: void(0);" class="btn btn-secondary"><?=$_["next"]?></a>
                                                    </li>
                                                </ul>
                                            </div>
                                            
                                           
                                            
                                            
                                            <div class="tab-pane" id="load-balancing">
                                                <div class="row">
                                                    <div class="col-12">
	                                                        <div class="form-group row mb-4">
																<label class="col-md-4 col-form-label" for="servers"><?=$_["server_tree"]?></label>
																<div class="col-md-8">
																	<select required name="servers" id="servers" class="form-control">
																	<option value="0" disabled selected><?=$_["choose_one_server"]?></option>
																	<?php
																		foreach(getStreamingServers() as $indice => $valor){
																			if ($valor['status'] == 2) {
																				$disabled = 'disabled';
																			}
																			echo "<option $disabled value=\"".$valor['id']."\">".$valor['server_name']."</option>";
																			
																		}
																	
																	?>
																	</select>																		
																</div>
															</div>
                                                        
                                                        <div class="form-group row mb-4" style="display:none">
                                                            <label class="col-md-4 col-form-label" for="tv_archive_server_id"><?=$_["timeshift_server"]?></label>
                                                            <div class="col-md-8">
                                                                <select name="tv_archive_server_id" id="tv_archive_server_id" class="form-control" data-toggle="select2">
                                                                    <option value=""><?=$_["timeshift_disabled"]?></option>
                                                                    <?php foreach ($rServers as $rServer) { ?>
                                                                    <option value="<?=$rServer["id"]?>"<?php if ((isset($rStream)) && ($rStream["tv_archive_server_id"] == $rServer["id"])) { echo " selected"; } ?>><?=$rServer["server_name"]?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row mb-4" style="display:none">
                                                            <label class="col-md-4 col-form-label" for="tv_archive_duration"><?=$_["timeshift_days"]?></label>
                                                            <div class="col-md-8">
                                                                <input type="text" class="form-control" id="tv_archive_duration" name="tv_archive_duration" value="<?php if (isset($rStream)) { echo $rStream["tv_archive_duration"]; } else { echo "0"; } ?>">
                                                                
                                                            </div>
                                                        </div>
                                                    </div> <!-- end col -->
                                                </div> <!-- end row -->
                                                <ul class="list-inline wizard mb-0">
                                                    <li class="previous list-inline-item">
                                                        <a href="javascript: void(0);" class="btn btn-secondary"><?=$_["previous"]?></a>
                                                    </li>
                                                    <li class="next list-inline-item float-right">
                                                        <input name="submit_stream" type="submit" class="btn btn-primary" value="<?php if (isset($rStream)) { echo $_["edit"]; } else { echo $_["add"]; } ?>" />
                                                    </li>
                                                </ul>
                                            </div>


                                        </div> <!-- tab-content -->
                                    </div> <!-- end #basicwizard-->
                                </form>

                            </div> <!-- end card-body -->
                        </div> <!-- end card-->
                    </div> <!-- end col -->
                </div>
            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->

        <!-- Footer Start -->
        <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 copyright text-center"><?=getFooter()?></div>
                </div>
            </div>
        </footer>
        <!-- end Footer -->

        <!-- Vendor js -->
        <script src="assets/js/vendor.min.js"></script>
        <script src="assets/libs/jquery-toast/jquery.toast.min.js"></script>
        <script src="assets/libs/jquery-nice-select/jquery.nice-select.min.js"></script>
        <script src="assets/libs/switchery/switchery.min.js"></script>
        <script src="assets/libs/select2/select2.min.js"></script>
        <script src="assets/libs/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
        <script src="assets/libs/bootstrap-maxlength/bootstrap-maxlength.min.js"></script>
        <script src="assets/libs/clockpicker/bootstrap-clockpicker.min.js"></script>
        <script src="assets/libs/datatables/jquery.dataTables.min.js"></script>
        <script src="assets/libs/datatables/dataTables.bootstrap4.js"></script>
        <script src="assets/libs/datatables/dataTables.responsive.min.js"></script>
        <script src="assets/libs/datatables/responsive.bootstrap4.min.js"></script>
        <script src="assets/libs/datatables/dataTables.buttons.min.js"></script>
        <script src="assets/libs/datatables/buttons.bootstrap4.min.js"></script>
        <script src="assets/libs/datatables/buttons.html5.min.js"></script>
        <script src="assets/libs/datatables/buttons.flash.min.js"></script>
        <script src="assets/libs/datatables/buttons.print.min.js"></script>
        <script src="assets/libs/datatables/dataTables.keyTable.min.js"></script>
        <script src="assets/libs/datatables/dataTables.select.min.js"></script>

        <!-- Plugins js-->
        <script src="assets/libs/twitter-bootstrap-wizard/jquery.bootstrap.wizard.min.js"></script>

        <!-- Tree view js -->
        <script src="assets/libs/treeview/jstree.min.js"></script>
        <script src="assets/js/pages/treeview.init.js"></script>
        <script src="assets/js/pages/form-wizard.init.js"></script>

        <!-- App js-->
        <script src="assets/js/app.min.js"></script>
        
        <script>
        var rEPG = <?=json_encode($rEPGJS)?>;
        
        (function($) {
          $.fn.inputFilter = function(inputFilter) {
            return this.on("input keydown keyup mousedown mouseup select contextmenu drop", function() {
              if (inputFilter(this.value)) {
                this.oldValue = this.value;
                this.oldSelectionStart = this.selectionStart;
                this.oldSelectionEnd = this.selectionEnd;
              } else if (this.hasOwnProperty("oldValue")) {
                this.value = this.oldValue;
                this.setSelectionRange(this.oldSelectionStart, this.oldSelectionEnd);
              }
            });
          };
        }(jQuery));
        
        function addStream() {
            $(".stream-url:first").clone().appendTo(".streams");
            $(".stream-url:last label").html("Stream URL");
            $(".stream-url:last input").val("");
        }
        function removeStream(rField) {
            if ($('.stream-url').length > 1) {
                $(rField).parent().parent().parent().remove();
            } else {
                $(rField).parent().parent().find("#stream_source").val("");
            }
        }
        function selectEPGSource() {
            $("#channel_id").empty();
            $("#epg_lang").empty();
            if (rEPG[$("#epg_id").val()]) {
                $.each(rEPG[$("#epg_id").val()], function(key, data) {
                    $("#channel_id").append(new Option(data["display_name"], key, false, false));
                });
                selectEPGID();
            }
        }
        function selectEPGID() {
            $("#epg_lang").empty();
            if (rEPG[$("#epg_id").val()][$("#channel_id").val()]) {
                $.each(rEPG[$("#epg_id").val()][$("#channel_id").val()]["langs"], function(i, data) {
                    $("#epg_lang").append(new Option(data, data, false, false));
                });
            }
        }
        function reloadStream() {
            $("#datatable").DataTable().ajax.reload( null, false );
            setTimeout(reloadStream, 5000);
        }
        function api(rID, rServerID, rType) {
            if (rType == "delete") {
                if (confirm('<?=$_["are_you_sure_you_want_to_delete_this_stream"]?>') == false) {
                    return;
                }
            }
            $.getJSON("./api.php?action=vod&sub=" + rType + "&stream_id=" + rID + "&server_id=" + rServerID, function(data) {
                if (data.result == true) {
                    if (rType == "start") {
                        $.toast("<?=$_["stream_successfully_started"]?>");
                    } else if (rType == "stop") {
                        $.toast("<?=$_["stream_successfully_stopped"]?>");
                    } else if (rType == "restart") {
                        $.toast("<?=$_["stream_successfully_restarted"]?>");
                    } else if (rType == "delete") {
                        $("#stream-" + rID + "-" + rServerID).remove();
                        $.toast("<?=$_["stream_successfully_deleted"]?>");
                    }
                    $("#datatable").DataTable().ajax.reload( null, false );
                } else {
                    $.toast("<?=$_["an_error_occured_while_processing_your_request"]?>");
                }
            }).fail(function() {
                $.toast("<?=$_["an_error_occured_while_processing_your_request"]?>");
            });
        }
        $(document).ready(function() {
            $('select').select2({width: '100%'}) 
            var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
            elems.forEach(function(html) {
              var switchery = new Switchery(html);
            });
            $("#epg_id").on("select2:select", function(e) { 
                selectEPGSource();
            });
            $("#channel_id").on("select2:select", function(e) { 
                selectEPGID();
            });
            
            $(".clockpicker").clockpicker();
            
            $('#server_tree').jstree({ 'core' : {
                'check_callback': function (op, node, parent, position, more) {
                    switch (op) {
                        case 'move_node':
                            if (node.id == "source") { return false; }
                            return true;
                    }
                },
                'data' : <?=json_encode($rServerTree)?>
            }, "plugins" : [ "dnd" ]
            });

            $(document).keypress(function(event){
                if (event.which == '13') {
                    event.preventDefault();
                }
            });
                   if (($("#m3u_file").val().length == 0) && ($("#m3u_url").val().length == 0)) {
                    e.preventDefault();
                    $.toast("<?=$_["please_select_a_m3u_file"]?>");
                }         
            $("#delay_minutes").inputFilter(function(value) { return /^\d*$/.test(value); });
            $("#tv_archive_duration").inputFilter(function(value) { return /^\d*$/.test(value); });
            $("form").attr('autocomplete', 'off');
            <?php if (isset($rStream)) { ?>
            $("#datatable").DataTable({
                ordering: false,
                paging: false,
                searching: false,
                processing: true,
                serverSide: true,
                bInfo: false,
                ajax: {
                    url: "./table.php",
                    "data": function(d) {
                        d.id = "vods",
                        d.vod_id = "<?=$rStream["id"]?>"
                    }
                },
                columnDefs: [
                    {"className": "dt-center", "targets": [3,4,5,6]},
                    {"visible": false, "targets": [0,1,2,7,8]}
                ],
            });
            setTimeout(reloadStream, 5000);
            <?php } ?>
        });
        </script>
    </body>
</html>